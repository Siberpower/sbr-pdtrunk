fx_version 'adamant'
game 'gta5'

author 'Siber#1001'

client_scripts {
	'client/client.lua'
}

server_scripts {
	'server/server.lua'
}

shared_script {
	'config.lua',
}

lua54 'yes'