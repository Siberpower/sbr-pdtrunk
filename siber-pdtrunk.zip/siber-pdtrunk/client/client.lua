local QBCore = exports["qb-core"]:GetCoreObject()

local trunkyakin = false
local m4secildi = false
local smgsecildi = false
local shotgunsecildi = false
local PlayerJob = {}

RegisterNetEvent("QBCore:Client:OnPlayerLoaded")
AddEventHandler(
    "QBCore:Client:OnPlayerLoaded",
    function()
        QBCore.Functions.GetPlayerData(
            function(PlayerData)
                PlayerJob = PlayerData.job
            end
        )
    end
)

RegisterNetEvent("QBCore:Client:OnJobUpdate")
AddEventHandler(
    "QBCore:Client:OnJobUpdate",
    function(JobInfo)
        PlayerJob = JobInfo
    end
)

AddEventHandler(
    "onClientResourceStart",
    function(resource)
        if GetCurrentResourceName() == resource then
            QBCore.Functions.GetPlayerData(
                function(PlayerData)
                    if PlayerData.job then
                        PlayerJob = PlayerData.job
                    end
                end
            )
        end
    end
)

RegisterNetEvent("pdtrunk:silahbirak")
AddEventHandler(
    "pdtrunk:silahbirak",
    function()
        if m4secildi then
            TriggerServerEvent("pdtrunk:weapon1birak")
            -- print("fix")
            QBCore.Functions.Notify(Config.Translations.put_weapon_in_trunk, "success")
            m4secildi = false
        elseif smgsecildi then
            TriggerServerEvent("pdtrunk:weapon2birak")
            smgsecildi = false
            QBCore.Functions.Notify(Config.Translations.put_weapon_in_trunk, "success")
        elseif shotgunsecildi then
            TriggerServerEvent("pdtrunk:weapon3birak")
            shotgunsecildi = false
            QBCore.Functions.Notify(Config.Translations.put_weapon_in_trunk, "success")
        else
            QBCore.Functions.Notify("Silah Almamışsın!", "error")
        end
    end
)

RegisterNetEvent("pdtrunk:weapon1")
AddEventHandler(
    "pdtrunk:weapon1",
    function()
        weapon1ver()
    end
)

RegisterNetEvent("pdtrunk:weapon2")
AddEventHandler(
    "pdtrunk:weapon2",
    function()
        weapon2ver()
    end
)

RegisterNetEvent("pdtrunk:weapon3")
AddEventHandler(
    "pdtrunk:weapon3",
    function()
        weapon3ver()
    end
)

function weapon1ver()
    if not m4secildi then
        if Config.UseProgressbar then
            TriggerServerEvent("pdtrunk:weapon1")
            m4secildi = true
            print(m4secildi)
            QBCore.Functions.Progressbar(
                "weapon1",
                Config.Translations.taking_weapon,
                Config.ProgressbarTime,
                false,
                true,
                {
                    -- Name | Label | Time | useWhileDead | canCancel
                    disableMovement = true,
                    disableCarMovement = true,
                    disableMouse = false,
                    disableCombat = true
                },
                {
                    animDict = "amb@prop_human_bum_bin@idle_b",
                    anim = "idle_d",
                    flags = 16
                },
                {},
                {},
                function()
                    -- Play When Done
                    --Stuff goes here
                end,
                function()
                    -- Play When Cancel
                    --Stuff goes here
                end
            )
            -- QBCore.Functions.Notify('M4 Aldın!', "success")
            QBCore.Functions.Notify(Config.Translations.take_weapon, "success")
        else
            TriggerServerEvent("pdtrunk:weapon1")
            m4secildi = true
            QBCore.Functions.Notify(Config.Translations.take_weapon, "success")
        end
    else
        QBCore.Functions.Notify(Config.Translations.already_took_weapon, "error")
    end
end

function weapon2ver()
    if not smgsecildi then
        if Config.UseProgressbar then
            TriggerServerEvent("pdtrunk:weapon2")
            smgsecildi = true
            print(smgsecildi)
            QBCore.Functions.Progressbar(
                "weapon2",
                Config.Translations.taking_weapon,
                Config.ProgressbarTime,
                false,
                true,
                {
                    -- Name | Label | Time | useWhileDead | canCancel
                    disableMovement = true,
                    disableCarMovement = true,
                    disableMouse = false,
                    disableCombat = true
                },
                {
                    animDict = "amb@prop_human_bum_bin@idle_b",
                    anim = "idle_d",
                    flags = 16
                },
                {},
                {},
                function()
                    -- Play When Done
                    --Stuff goes here
                end,
                function()
                    -- Play When Cancel
                    --Stuff goes here
                end
            )
            -- QBCore.Functions.Notify('M4 Aldın!', "success")
            QBCore.Functions.Notify(Config.Translations.take_weapon, "success")
        else
            TriggerServerEvent("pdtrunk:weapon2")
            smgsecildi = true
            QBCore.Functions.Notify(Config.Translations.take_weapon, "success")
        end
    else
        QBCore.Functions.Notify(Config.Translations.already_took_weapon, "error")
    end
end

function weapon3ver()
    if not shotgunsecildi then
        if Config.UseProgressbar then
            TriggerServerEvent("pdtrunk:weapon3")
            shotgunsecildi = true
            print(shotgunsecildi)
            QBCore.Functions.Progressbar(
                "weapon3",
                Config.Translations.taking_weapon,
                Config.ProgressbarTime,
                false,
                true,
                {
                    -- Name | Label | Time | useWhileDead | canCancel
                    disableMovement = true,
                    disableCarMovement = true,
                    disableMouse = false,
                    disableCombat = true
                },
                {
                    animDict = "amb@prop_human_bum_bin@idle_b",
                    anim = "idle_d",
                    flags = 16
                },
                {},
                {},
                function()
                    -- Play When Done
                    --Stuff goes here
                end,
                function()
                    -- Play When Cancel
                    --Stuff goes here
                end
            )
            -- QBCore.Functions.Notify('M4 Aldın!', "success")
            QBCore.Functions.Notify(Config.Translations.take_weapon, "success")
        else
            TriggerServerEvent("pdtrunk:weapon3")
            shotgunsecildi = true
            QBCore.Functions.Notify(Config.Translations.take_weapon, "success")
        end
    else
        QBCore.Functions.Notify(Config.Translations.already_took_weapon, "error")
    end
end

RegisterNetEvent("pdtrunk:openmenu")
AddEventHandler(
    "pdtrunk:openmenu",
    function()
        if PlayerJob.name == "police" then
            local vehicle, mesafe = QBCore.Functions.GetClosestVehicle(GetEntityCoords(PlayerPedId()))
            if mesafe < 4 then
                local trunk = GetEntityBoneIndexByName(vehicle, "boot")
                if trunk ~= -1 then
                    local coords = GetWorldPositionOfEntityBone(vehicle, trunk)
                    if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), coords, true) <= 2 then
                        if GetVehicleClass(vehicle) == 18 then
                            exports["qb-menu"]:openMenu(
                                {
                                    {
                                        header = Config.Translations.trunk,
                                        icon = "",
                                        isMenuHeader = true -- Set to true to make a nonclickable title
                                    },
                                    {
                                        header = Config.Translations.take_weapon_from_trunk,
                                        txt = "",
                                        icon = "",
                                        -- disabled = false, -- optional, non-clickable and grey scale
                                        -- hidden = true, -- optional, hides the button completely
                                        params = {
                                            -- isServer = false, -- optional, specify event type
                                            event = "pdtrunk:silahmenu",
                                            args = {
                                                number = 2
                                            }
                                        }
                                    },
                                    {
                                        header = Config.Translations.put_weapon_back_to_trunk,
                                        txt = "",
                                        icon = "",
                                        params = {
                                            event = "pdtrunk:silahbirak",
                                            args = {}
                                        }
                                    }
                                }
                            )
                      else
                        QBCore.Functions.Notify(Config.Translations.wrong_car_type, "error")
                      end
                    else
                        QBCore.Functions.Notify(Config.Translations.no_trunk_nearby, "error")
                    end
            else
                QBCore.Functions.Notify(Config.Translations.no_car_nearby, "error")
            end
        else
            QBCore.Functions.Notify(Config.Translations.cant_do_that, "error")
        end
    end
end
)

RegisterNetEvent(
    "pdtrunk:silahmenu",
    function(data)
        local number = data.number
        exports["qb-menu"]:openMenu(
            {
                {
                    header = Config.Translations.go_back,
                    icon = "fa-solid fa-backward",
                    params = {
                        event = "pdtrunk:openmenu",
                        args = {}
                    }
                },
                {
                    header = Config.Translations.take_weapon1,
                    txt = "",
                    icon = "fas fa-gun",
                    params = {
                        event = "pdtrunk:weapon1",
                        args = {}
                    }
                },
                {
                    header = Config.Translations.take_weapon2,
                    txt = "",
                    icon = "fas fa-gun",
                    params = {
                        event = "pdtrunk:weapon2",
                        args = {}
                    }
                },
                {
                    header = Config.Translations.take_weapon3,
                    txt = "",
                    icon = "fas fa-gun",
                    params = {
                        event = "pdtrunk:weapon3",
                        args = {}
                    }
                }
            }
        )
    end
)
