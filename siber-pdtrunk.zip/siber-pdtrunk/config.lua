Config = Config or {}

local miliseconds = 700
Config.UseProgressbar = true
Config.ProgressbarTime = 5 * miliseconds -- Seconds 

Config.Weapon1 = 'weapon_carbinerifle'
Config.Weapon2 = 'weapon_smg'
Config.Weapon3 = 'weapon_combatpdw'

Config.Translations = {
    put_weapon_in_trunk = "You have put a gun in trunk!",
    take_weapon = "You took a gun!",
    already_took_weapon = "You Already Took A Weapon!",
    no_trunk_nearby = "There is no trunk nearby!",
    cant_do_that = "Can't do that!",
    take_weapon1 = "Take Carbine Rifle",
    take_weapon2 = "Take SMG",
    take_weapon3 = "Take PDW",
    taking_weapon = "Taking weapon from trunk",
    no_car_nearby = "There Is No Car Nearby!",
    go_back = "Go Back",
    put_weapon_back_to_trunk = "Put weapon back to trunk",
    take_weapon_from_trunk = "Take weapon from trunk",
    trunk = "Trunk",
    wrong_car_type = "Wrong Car Type!"
}