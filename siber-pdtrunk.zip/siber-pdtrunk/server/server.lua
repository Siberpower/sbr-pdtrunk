local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('pdtrunk:weapon1', function(data)
	local src = source
	local player = QBCore.Functions.GetPlayer(src)	
	player.Functions.AddItem(Config.Weapon1, 1)
end)

RegisterNetEvent("pdtrunk:weapon1birak", function()
	local src = source
	local player = QBCore.Functions.GetPlayer(src)
	player.Functions.RemoveItem(Config.Weapon1, 1)
end)

RegisterNetEvent('pdtrunk:weapon2', function(data)
	local src = source
	local player = QBCore.Functions.GetPlayer(src)	
	player.Functions.AddItem(Config.Weapon2, 1)
end)

RegisterNetEvent("pdtrunk:weapon2birak", function()
	local src = source
	local player = QBCore.Functions.GetPlayer(src)
	player.Functions.RemoveItem(Config.Weapon2, 1)
end)

RegisterNetEvent('pdtrunk:weapon3', function(data)
	local src = source
	local player = QBCore.Functions.GetPlayer(src)	
	player.Functions.AddItem(Config.Weapon3, 1)
end)

RegisterNetEvent("pdtrunk:weapon3birak", function()
	local src = source
	local player = QBCore.Functions.GetPlayer(src)
	player.Functions.RemoveItem(Config.Weapon3, 1)
end)